# Late Life Crisis

A minimalist website for Nettspend's "Early Life Crisis" album, styled after xeno.onl's aesthetic.

## About

This site is a play on Nettspend's upcoming album "Early Life Crisis", featuring:
- Album information and release date (2/27/26)
- North America tour dates
- Official links and contact information
- All snippets video and song list

## Setup for GitHub Pages

1. Create a new repository on GitHub
2. Upload all files to the repository:
   - `index.html`
   - `dates.html`
   - `links.html`
   - `music.html`
   - `style.css`
   - `README.md`

3. Enable GitHub Pages:
   - Go to repository Settings
   - Navigate to "Pages" in the left sidebar
   - Under "Source", select "Deploy from a branch"
   - Select "main" branch and "/ (root)" folder
   - Click Save

4. Your site will be live at: `https://[your-username].github.io/[repository-name]/`

## Features

- **Minimalist Design**: Black and white aesthetic inspired by xeno.onl
- **Responsive Layout**: Works on desktop and mobile devices
- **Four Pages**:
  - Home: Hero image with title
  - Dates: Album release date and tour schedule
  - Links: Album cover, official links, and contact info
  - Music: Snippets video and song list

## Credits

- Design inspired by xeno.onl
- Built for Nettspend's "Early Life Crisis" album
- Album artwork and media from official sources

## Artist Information

**Nettspend** (Gunner Shepardson) is an American rapper from Richmond, Virginia. His musical style stems from trap and jerk subgenres, characterized by distorted 808s, loose piano riffs, and glimmering synths. He's affiliated with Xaviersobased's collective 1c34.

Early Life Crisis releases February 27, 2026.
